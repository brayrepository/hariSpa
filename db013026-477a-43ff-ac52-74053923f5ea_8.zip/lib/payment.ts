
// Configuración para integración con PSE
export const PSE_CONFIG = {
  // Para PSE (Colombia)
  pse: {
    merchantId: 'your_merchant_id', // Tu ID de comercio
    apiKey: 'your_api_key', // Tu API Key
    accountId: 'your_account_id', // Tu Account ID
    apiUrl: 'https://sandbox.api.payulatam.com/payments-api/', // Sandbox URL
    // apiUrl: 'https://api.payulatam.com/payments-api/', // Production URL
  }
};

// Función para procesar pagos con PSE
export const processPSEPayment = async (paymentData: any, appointmentData: any) => {
  try {
    const reference = `harispa_${Date.now()}`;
    const amount = 10000; // Valor fijo para apartar cita
    
    const paymentRequest = {
      language: 'es',
      command: 'SUBMIT_TRANSACTION',
      merchant: {
        apiKey: PSE_CONFIG.pse.apiKey,
        apiLogin: 'your_api_login', // Tu API Login
      },
      transaction: {
        order: {
          accountId: PSE_CONFIG.pse.accountId,
          referenceCode: reference,
          description: `Cita HariSpa - ${appointmentData.service} - ${appointmentData.fullName}`,
          language: 'es',
          signature: 'generated_signature', // Necesitas generar la firma
          additionalValues: {
            TX_VALUE: {
              value: amount,
              currency: 'COP'
            }
          },
          buyer: {
            merchantBuyerId: appointmentData.cedula,
            fullName: appointmentData.fullName,
            emailAddress: 'cliente@email.com', // Campo email requerido
            contactPhone: appointmentData.phone,
            dniNumber: appointmentData.cedula,
          }
        },
        payer: {
          merchantPayerId: appointmentData.cedula,
          fullName: appointmentData.fullName,
          emailAddress: 'cliente@email.com',
          contactPhone: appointmentData.phone,
          dniNumber: appointmentData.cedula,
        },
        type: 'AUTHORIZATION_AND_CAPTURE',
        paymentMethod: 'PSE',
        paymentCountry: 'CO',
        deviceSessionId: reference,
        ipAddress: '127.0.0.1',
        cookie: 'pt1t38347bs6jc9ruv2ecpv7o2',
        userAgent: 'Mozilla/5.0',
        extraParameters: {
          FINANCIAL_INSTITUTION_CODE: paymentData.bankCode,
          USER_TYPE: paymentData.personType, // 'N' para natural, 'J' para jurídica
          PSE_REFERENCE1: reference,
          PSE_REFERENCE2: appointmentData.fullName,
          PSE_REFERENCE3: appointmentData.phone
        }
      },
      test: true // Cambiar a false en producción
    };

    const response = await fetch(PSE_CONFIG.pse.apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(paymentRequest)
    });

    const result = await response.json();
    
    if (result.code === 'SUCCESS') {
      // PSE devuelve una URL para redireccionar al banco
      return {
        success: true,
        bankUrl: result.transaction.extraParameters.BANK_URL,
        transactionId: result.transaction.id,
        reference: reference
      };
    } else {
      throw new Error(result.error || 'Error en el procesamiento PSE');
    }

  } catch (error) {
    console.error('Error processing PSE payment:', error);
    throw error;
  }
};

// Función para generar referencia única para HariSpa
export const generateHariSpaReference = () => {
  return `harispa_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Función para validar número de cédula colombiana
export const validateCedula = (cedula: string) => {
  const num = cedula.replace(/\D/g, '');
  
  if (num.length < 6 || num.length > 10) {
    return false;
  }
  
  // Validación básica - puedes implementar el algoritmo completo si lo necesitas
  return /^\d+$/.test(num);
};

// Función para validar teléfono colombiano
export const validatePhoneNumber = (phone: string) => {
  const num = phone.replace(/\D/g, '');
  
  // Teléfonos colombianos tienen 10 dígitos y empiezan con 3
  return num.length === 10 && num.startsWith('3');
};

// Función para obtener códigos de bancos PSE
export const getPSEBanks = () => {
  return [
    { code: '1007', name: 'Bancolombia' },
    { code: '1051', name: 'Davivienda' },
    { code: '1001', name: 'Banco de Bogotá' },
    { code: '1013', name: 'BBVA Colombia' },
    { code: '1002', name: 'Banco Popular' },
    { code: '1012', name: 'Colpatria' },
    { code: '1006', name: 'Banco Corpbanca' },
    { code: '1009', name: 'Citibank' },
    { code: '1370', name: 'Banco Caja Social' },
    { code: '1292', name: 'Banco Falabella' }
  ];
};

// Función para simular procesamiento PSE (para desarrollo)
export const simulatePSEPayment = async (paymentData: any, appointmentData: any) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        transactionId: `TXN_${Date.now()}`,
        reference: generateHariSpaReference(),
        message: 'Pago PSE procesado exitosamente'
      });
    }, 3000);
  });
};
