
export interface EmailData {
  to: string;
  subject: string;
  html: string;
}

export const sendEmail = async (data: EmailData): Promise<boolean> => {
  try {
    console.log('Simulando envío de email:', {
      to: data.to,
      subject: data.subject,
      content: data.html
    });
    
    return true;
  } catch (error) {
    console.error('Error enviando email:', error);
    return false;
  }
};

export const generateAppointmentEmail = (appointmentData: {
  fullName: string;
  phone: string;
  service: string;
  date: string;
  time: string;
}): string => {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('es-ES', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const formatTime = (timeStr: string) => {
    return timeStr + ':00 - ' + (parseInt(timeStr.split(':')[0]) + 2) + ':00';
  };

  const serviceNames = {
    'permanente': 'Permanente',
    'tradicional': 'Tradicional',
    'semi': 'Semi',
    'poli': 'Poli',
    'gel': 'Gel'
  };

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Confirmación de Cita</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px 10px 0 0; text-align: center; }
        .content { background: white; padding: 30px; border: 1px solid #e1e5e9; }
        .footer { background: #f8f9fa; padding: 20px; border-radius: 0 0 10px 10px; text-align: center; color: #6c757d; }
        .detail-row { margin: 15px 0; padding: 10px; background: #f8f9ff; border-radius: 5px; }
        .label { font-weight: bold; color: #5a67d8; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>¡Cita Confirmada!</h1>
          <p>Tu cita ha sido agendada exitosamente</p>
        </div>
        
        <div class="content">
          <h2>Detalles de tu cita:</h2>
          
          <div class="detail-row">
            <span class="label">Cliente:</span> ${appointmentData.fullName}
          </div>
          
          <div class="detail-row">
            <span class="label">Teléfono:</span> ${appointmentData.phone}
          </div>
          
          <div class="detail-row">
            <span class="label">Servicio:</span> ${serviceNames[appointmentData.service] || appointmentData.service}
          </div>
          
          <div class="detail-row">
            <span class="label">Fecha:</span> ${formatDate(appointmentData.date)}
          </div>
          
          <div class="detail-row">
            <span class="label">Horario:</span> ${formatTime(appointmentData.time)}
          </div>
          
          <div style="margin-top: 30px; padding: 20px; background: #e6fffa; border-radius: 5px; border-left: 4px solid #38b2ac;">
            <h3 style="margin-top: 0; color: #2d3748;">Información importante:</h3>
            <ul style="margin: 0; padding-left: 20px;">
              <li>Por favor llega 10 minutos antes de tu cita</li>
              <li>Si necesitas cancelar o reprogramar, hazlo con al menos 24 horas de anticipación</li>
              <li>Duración del servicio: 2 horas</li>
            </ul>
          </div>
        </div>
        
        <div class="footer">
          <p>¡Gracias por confiar en nosotros!</p>
          <p style="font-size: 12px; margin-top: 15px;">
            Este es un correo automático, no responder directamente.
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
};
