
'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

const SERVICES = [
  { value: 'permanente', label: 'Permanente', price: 150000 },
  { value: 'tradicional', label: 'Tradicional', price: 80000 },
  { value: 'semi', label: 'Semi', price: 120000 },
  { value: 'poli', label: 'Poli', price: 100000 },
  { value: 'gel', label: 'Gel', price: 90000 }
];

const WORKING_HOURS = [
  '06:00', '08:00', '10:00', '14:00', '16:00', '18:00'
];

export default function Home() {
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    cedula: '',
    service: ''
  });
  const [appointments, setAppointments] = useState([]);
  const [isFormComplete, setIsFormComplete] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: ''
  });
  const [paymentStep, setPaymentStep] = useState(1);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);

    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const date = urlParams.get('date');
      const time = urlParams.get('time');

      if (date && time) {
        setSelectedDate(date);
        setSelectedTime(time);
      }

      const saved = localStorage.getItem('appointments');
      if (saved) {
        setAppointments(JSON.parse(saved));
      }
    }
  }, []);

  useEffect(() => {
    const { fullName, phone, cedula, service } = formData;
    setIsFormComplete(
      fullName.trim() !== '' && 
      phone.trim() !== '' && 
      cedula.trim() !== '' && 
      service !== '' && 
      selectedDate && 
      selectedTime
    );
  }, [formData, selectedDate, selectedTime]);

  const handleFullNameChange = (value) => {
    // Solo permitir letras y espacios
    const filtered = value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]/g, '');
    setFormData(prev => ({ ...prev, fullName: filtered }));
  };

  const handlePhoneChange = (value) => {
    // Solo permitir números y limitar a 10 dígitos
    const filtered = value.replace(/[^0-9]/g, '').slice(0, 10);
    setFormData(prev => ({ ...prev, phone: filtered }));
  };

  const handleCedulaChange = (value) => {
    // Solo permitir números
    const filtered = value.replace(/[^0-9]/g, '');
    setFormData(prev => ({ ...prev, cedula: filtered }));
  };

  const handleInputChange = (field, value) => {
    if (field === 'fullName') {
      handleFullNameChange(value);
    } else if (field === 'phone') {
      handlePhoneChange(value);
    } else if (field === 'cedula') {
      handleCedulaChange(value);
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  const isDateTimeAvailable = (date, time) => {
    return !appointments.some(apt => apt.date === date && apt.time === time);
  };

  const getAvailableDates = () => {
    if (!mounted) return [];
    
    const dates = [];
    const today = new Date();
    
    for (let i = 0; i < 30; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push(date.toISOString().split('T')[0]);
    }
    
    return dates;
  };

  const getAvailableTimesForDate = (date) => {
    return WORKING_HOURS.filter(time => isDateTimeAvailable(date, time));
  };

  const getSelectedServicePrice = () => {
    const service = SERVICES.find(s => s.value === formData.service);
    return service ? service.price : 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!isFormComplete) return;

    if (!isDateTimeAvailable(selectedDate, selectedTime)) {
      alert('Esta fecha y hora ya no está disponible. Por favor selecciona otra.');
      return;
    }

    setShowPayment(true);
  };

  const handlePayment = async (e) => {
    e.preventDefault();
    setIsProcessingPayment(true);

    // Simular procesamiento de pago PSE
    setTimeout(() => {
      const newAppointment = {
        id: Date.now(),
        date: selectedDate,
        time: selectedTime,
        fullName: formData.fullName,
        phone: formData.phone,
        cedula: formData.cedula,
        service: formData.service,
        amount: 10000, // Valor fijo de $10,000 COP
        paymentStatus: 'paid',
        createdAt: new Date().toISOString()
      };

      const updatedAppointments = [...appointments, newAppointment];
      setAppointments(updatedAppointments);
      
      if (typeof window !== 'undefined') {
        localStorage.setItem('appointments', JSON.stringify(updatedAppointments));
      }

      setFormData({ fullName: '', phone: '', cedula: '', service: '' });
      setSelectedDate('');
      setSelectedTime('');
      setPaymentData({ cardNumber: '', expiryDate: '', cvv: '', cardName: '' });
      setShowPayment(false);
      setIsProcessingPayment(false);
      setPaymentStep(1);
      setShowSuccess(true);

      if (typeof window !== 'undefined') {
        const searchParams = new URLSearchParams(window.location.search);
        searchParams.delete('date');
        searchParams.delete('time');
        const newUrl = window.location.pathname + (searchParams.toString() ? '?' + searchParams.toString() : '');
        window.history.replaceState({}, '', newUrl);
      }
    }, 3000);
  };

  const formatDate = (dateStr) => {
    if (!mounted) return '';
    const date = new Date(dateStr + 'T00:00:00');
    return date.toLocaleDateString('es-ES', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const formatTime = (timeStr) => {
    return timeStr + ':00';
  };

  const formatPrice = (price) => {
    if (!mounted) return price.toString();
    return price.toLocaleString();
  };

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const handleCloseSuccess = () => {
    setShowSuccess(false);
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-600 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-sm shadow-sm z-10">
        <div className="flex items-center justify-between px-4 py-3">
          <div></div>
          <Link href="/admin" className="flex items-center justify-center w-8 h-8 text-purple-600">
            <i className="ri-admin-line text-xl"></i>
          </Link>
        </div>
      </nav>

      <div className="pt-20 pb-6 px-4">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-purple-800 mb-4" style={{fontFamily: 'Dancing Script, cursive'}}>
              H'ari Spa
            </h1>
            <p className="text-gray-800 text-lg font-bold">Ingresa tus datos para agendar tu cita con nosotras.</p>
            <p className="text-purple-600 text-lg mt-2">¡Te esperamos!</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre Completo
                  </label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => handleInputChange('fullName', e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm"
                    placeholder="Ingresa tu nombre completo"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Número de Teléfono
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm"
                    placeholder="Ingresa tu número de teléfono (10 dígitos)"
                    maxLength="10"
                    required
                  />
                  {formData.phone && formData.phone.length < 10 && (
                    <p className="text-red-500 text-xs mt-1">Debe tener 10 dígitos</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Número de Cédula
                  </label>
                  <input
                    type="text"
                    value={formData.cedula}
                    onChange={(e) => handleInputChange('cedula', e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm"
                    placeholder="Ingresa tu número de cédula"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tipo de Servicio
                  </label>
                  <div className="relative">
                    <select
                      value={formData.service}
                      onChange={(e) => handleInputChange('service', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm appearance-none bg-white"
                      required
                    >
                      <option value="">Selecciona un servicio</option>
                      {SERVICES.map((service) => (
                        <option key={service.value} value={service.value}>
                          {service.label} - ${formatPrice(service.price)} COP
                        </option>
                      ))}
                    </select>
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center justify-center w-4 h-4">
                      <i className="ri-arrow-down-s-line text-gray-400"></i>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Fecha
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      setSelectedTime('');
                    }}
                    min={new Date().toISOString().split('T')[0]}
                    max={new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm"
                    required
                  />
                </div>

                {selectedDate && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Hora Disponible
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {getAvailableTimesForDate(selectedDate).map(time => (
                        <button
                          key={time}
                          type="button"
                          onClick={() => setSelectedTime(time)}
                          className={`p-3 rounded-xl text-sm font-medium transition-all !rounded-button ${
                            selectedTime === time
                              ? 'bg-purple-600 text-white'
                              : 'bg-purple-50 text-purple-700 hover:bg-purple-100'
                          }`}
                        >
                          {time} - {parseInt(time.split(':')[0]) + 2}:00
                        </button>
                      ))}
                    </div>
                    {getAvailableTimesForDate(selectedDate).length === 0 && (
                      <p className="text-red-600 text-sm text-center py-4">
                        No hay horarios disponibles para esta fecha
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
              <span className="text-purple-800 font-bold">El valor mínimo para agendar tu cita es de $10.000 COP</span>
            </div>

            {selectedDate && selectedTime && (
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-purple-100">
                <div className="flex items-center mb-2">
                  <div className="flex items-center justify-center w-6 h-6 mr-3">
                    <i className="ri-calendar-check-line text-purple-600"></i>
                  </div>
                  <span className="text-sm font-medium text-gray-700">Fecha y hora seleccionada</span>
                </div>
                <p className="text-gray-800 font-medium capitalize">{formatDate(selectedDate)}</p>
                <p className="text-purple-600 font-medium">{formatTime(selectedTime)} - {parseInt(selectedTime.split(':')[0]) + 2}:00</p>
              </div>
            )}

            <button
              type="submit"
              disabled={!isFormComplete || (formData.phone && formData.phone.length !== 10)}
              className={`w-full py-4 rounded-xl font-medium !rounded-button ${
                isFormComplete && (!formData.phone || formData.phone.length === 10)
                  ? 'bg-purple-600 text-white shadow-lg'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              <div className="flex items-center justify-center">
                <div className="flex items-center justify-center w-5 h-5 mr-2">
                  <i className="ri-secure-payment-line"></i>
                </div>
                Pagar con PSE
              </div>
            </button>
          </form>

          {showPayment && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
              <div className="bg-white rounded-2xl p-6 max-w-sm w-full max-h-[90vh] overflow-y-auto">
                <div className="text-center mb-6">
                  <div className="flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mx-auto mb-4">
                    <i className="ri-bank-line text-2xl text-purple-600"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800 mb-2">Pago con PSE</h3>
                  <p className="text-gray-600 text-sm">Total: $10.000 COP</p>
                </div>
                
                <form onSubmit={handlePayment} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Banco
                    </label>
                    <div className="relative">
                      <select className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm appearance-none bg-white" required>
                        <option value="">Selecciona tu banco</option>
                        <option value="bancolombia">Bancolombia</option>
                        <option value="davivienda">Davivienda</option>
                        <option value="banco_bogota">Banco de Bogotá</option>
                        <option value="bbva">BBVA</option>
                        <option value="banco_popular">Banco Popular</option>
                        <option value="colpatria">Colpatria</option>
                      </select>
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center justify-center w-4 h-4 pointer-events-none">
                        <i className="ri-arrow-down-s-line text-gray-400"></i>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tipo de Persona
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <label className="flex items-center p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50">
                        <input type="radio" name="personType" value="natural" className="mr-2" required />
                        <span className="text-sm">Natural</span>
                      </label>
                      <label className="flex items-center p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50">
                        <input type="radio" name="personType" value="juridica" className="mr-2" required />
                        <span className="text-sm">Jurídica</span>
                      </label>
                    </div>
                  </div>

                  <div className="flex gap-3 mt-6">
                    <button
                      type="button"
                      onClick={() => setShowPayment(false)}
                      className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium !rounded-button"
                      disabled={isProcessingPayment}
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-purple-600 text-white py-3 rounded-xl font-medium !rounded-button"
                      disabled={isProcessingPayment}
                    >
                      {isProcessingPayment ? (
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                          Procesando...
                        </div>
                      ) : (
                        'Pagar con PSE'
                      )}
                    </button>
                  </div>
                </form>

                <div className="mt-4 text-center">
                  <div className="flex items-center justify-center text-xs text-gray-500">
                    <div className="flex items-center justify-center w-4 h-4 mr-1">
                      <i className="ri-shield-check-line"></i>
                    </div>
                    Pago seguro con PSE
                  </div>
                </div>
              </div>
            </div>
          )}

          {showSuccess && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
              <div className="bg-white rounded-2xl p-6 max-w-sm w-full text-center">
                <div className="flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mx-auto mb-4">
                  <i className="ri-check-line text-2xl text-green-600"></i>
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-4">¡Pago confirmado!</h3>
                <div className="bg-gray-50 rounded-xl p-4 text-sm text-gray-700 leading-relaxed text-center mb-6">
                  <p className="mb-2">Tu cita ha sido agendada.</p>
                  <p className="mb-2">Si no puedes asistir, por favor confirma la cancelación. En caso contrario, el abono no será reembolsado.</p>
                  <p>Puedes solicitar una nueva cita dentro de los próximos 8 días. Pasado este plazo, el abono se perderá.</p>
                </div>
                <button
                  onClick={handleCloseSuccess}
                  className="w-full bg-purple-600 text-white py-3 rounded-xl font-medium !rounded-button"
                >
                  Aceptar
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
