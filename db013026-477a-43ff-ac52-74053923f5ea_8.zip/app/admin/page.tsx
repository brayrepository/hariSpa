
'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

const SERVICES = {
  'permanente': 'Permanente',
  'tradicional': 'Tradicional',
  'semi': 'Semi',
  'poli': 'Poli',
  'gel': 'Gel'
};

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [appointments, setAppointments] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);
  const [filterDate, setFilterDate] = useState('all');

  useEffect(() => {
    const authStatus = localStorage.getItem('adminAuth');
    if (authStatus === 'authenticated') {
      setIsAuthenticated(true);
      loadAppointments();
    }
  }, []);

  const loadAppointments = () => {
    const saved = localStorage.getItem('appointments');
    if (saved) {
      setAppointments(JSON.parse(saved));
    }
  };

  const handleLogin = (e) => {
    e.preventDefault();
    if (loginForm.username === 'admin' && loginForm.password === 'admin123') {
      setIsAuthenticated(true);
      localStorage.setItem('adminAuth', 'authenticated');
      loadAppointments();
      setLoginError('');
    } else {
      setLoginError('Usuario o contraseña incorrectos');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('adminAuth');
    setLoginForm({ username: '', password: '' });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-sm p-8 w-full max-w-sm">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mx-auto mb-4">
              <i className="ri-admin-line text-2xl text-purple-600"></i>
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Acceso Administrativo</h1>
            <p className="text-gray-600 text-sm">Ingresa tus credenciales para continuar</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Usuario</label>
              <input
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm"
                placeholder="Ingresa tu usuario"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Contraseña</label>
              <input
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 focus:outline-none text-sm"
                placeholder="Ingresa tu contraseña"
                required
              />
            </div>

            {loginError && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3">
                <p className="text-red-600 text-sm text-center">{loginError}</p>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-purple-600 text-white py-3 rounded-xl font-medium !rounded-button"
            >
              <div className="flex items-center justify-center">
                <div className="flex items-center justify-center w-5 h-5 mr-2">
                  <i className="ri-login-circle-line"></i>
                </div>
                Iniciar Sesión
              </div>
            </button>
          </form>

          <div className="mt-6 text-center">
            <Link href="/" className="text-purple-600 text-sm hover:underline">
              Volver al inicio
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const saveAppointments = (newAppointments) => {
    setAppointments(newAppointments);
    localStorage.setItem('appointments', JSON.stringify(newAppointments));
  };

  const handleEdit = (appointment) => {
    setEditingId(appointment.id);
    setEditForm({
      fullName: appointment.fullName,
      phone: appointment.phone,
      service: appointment.service,
      date: appointment.date,
      time: appointment.time
    });
  };

  const handleSaveEdit = () => {
    const updatedAppointments = appointments.map(apt =>
      apt.id === editingId ? { ...apt, ...editForm } : apt
    );
    saveAppointments(updatedAppointments);
    setEditingId(null);
    setEditForm({});
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditForm({});
  };

  const handleDelete = (id) => {
    const updatedAppointments = appointments.filter(apt => apt.id !== id);
    saveAppointments(updatedAppointments);
    setShowDeleteConfirm(null);
  };

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeStr) => {
    return timeStr + ':00 - ' + (parseInt(timeStr.split(':')[0]) + 2) + ':00';
  };

  const getFilteredAppointments = () => {
    if (filterDate === 'all') return appointments;

    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (filterDate === 'today') {
      return appointments.filter(apt => apt.date === todayStr);
    } else if (filterDate === 'upcoming') {
      return appointments.filter(apt => apt.date >= todayStr);
    } else if (filterDate === 'past') {
      return appointments.filter(apt => apt.date < todayStr);
    }

    return appointments;
  };

  const sortedAppointments = getFilteredAppointments().sort((a, b) => {
    const dateA = new Date(a.date + 'T' + a.time);
    const dateB = new Date(b.date + 'T' + b.time);
    return dateA - dateB;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-sm shadow-sm z-10">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center justify-center w-8 h-8 text-purple-600">
            <i className="ri-arrow-left-line text-xl"></i>
          </Link>
          <h1 className="text-lg font-bold text-purple-800" style={{ fontFamily: 'Pacifico, serif' }}>
            Administrador
          </h1>
          <button
            onClick={handleLogout}
            className="flex items-center justify-center w-8 h-8 text-red-600"
          >
            <i className="ri-logout-circle-r-line text-xl"></i>
          </button>
        </div>
      </nav>

      <div className="pt-20 pb-6 px-4">
        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-2xl shadow-sm p-4 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-gray-800">Filtrar Citas</h2>
              <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
                {sortedAppointments.length}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { value: 'all', label: 'Todas' },
                { value: 'today', label: 'Hoy' },
                { value: 'upcoming', label: 'Próximas' },
                { value: 'past', label: 'Pasadas' }
              ].map(filter => (
                <button
                  key={filter.value}
                  onClick={() => setFilterDate(filter.value)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium !rounded-button ${
                    filterDate === filter.value
                      ? 'bg-purple-600 text-white'
                      : 'bg-purple-50 text-purple-700'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            {sortedAppointments.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-sm p-8 text-center">
                <div className="flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mx-auto mb-4">
                  <i className="ri-calendar-line text-2xl text-gray-400"></i>
                </div>
                <h3 className="text-lg font-medium text-gray-600 mb-2">No hay citas</h3>
                <p className="text-gray-500 text-sm">No se encontraron citas para el filtro seleccionado</p>
              </div>
            ) : (
              sortedAppointments.map(appointment => (
                <div key={appointment.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                  {editingId === appointment.id ? (
                    <div className="p-6 space-y-4">
                      <input
                        type="text"
                        value={editForm.fullName}
                        onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                        placeholder="Nombre completo"
                      />
                      <input
                        type="tel"
                        value={editForm.phone}
                        onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                        placeholder="Teléfono"
                      />
                      <select
                        value={editForm.service}
                        onChange={(e) => setEditForm({ ...editForm, service: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                      >
                        {Object.entries(SERVICES).map(([value, label]) => (
                          <option key={value} value={value}>
                            {label}
                          </option>
                        ))}
                      </select>
                      <input
                        type="date"
                        value={editForm.date}
                        onChange={(e) => setEditForm({ ...editForm, date: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                      />
                      <select
                        value={editForm.time}
                        onChange={(e) => setEditForm({ ...editForm, time: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                      >
                        {['06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00'].map(time => (
                          <option key={time} value={time}>
                            {time}
                          </option>
                        ))}
                      </select>

                      <div className="flex gap-2">
                        <button
                          onClick={handleSaveEdit}
                          className="flex-1 bg-green-600 text-white py-2 rounded-lg text-sm font-medium !rounded-button"
                        >
                          Guardar
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg text-sm font-medium !rounded-button"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-bold text-gray-800">{appointment.fullName}</h3>
                          <p className="text-sm text-gray-600">{appointment.phone}</p>
                          {appointment.paymentStatus && (
                            <span
                              className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-1 ${
                                appointment.paymentStatus === 'paid'
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-yellow-100 text-yellow-800'
                              }`}
                            >
                              {appointment.paymentStatus === 'paid' ? 'Pagado' : 'Pendiente'}
                            </span>
                          )}
                        </div>
                        <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-lg text-xs font-medium">
                          {SERVICES[appointment.service]}
                        </span>
                      </div>

                      <div className="space-y-2 mb-4">
                        <div className="flex items-center text-sm text-gray-600">
                          <div className="flex items-center justify-center w-4 h-4 mr-2">
                            <i className="ri-calendar-line"></i>
                          </div>
                          <span className="capitalize">{formatDate(appointment.date)}</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <div className="flex items-center justify-center w-4 h-4 mr-2">
                            <i className="ri-time-line"></i>
                          </div>
                          <span>{formatTime(appointment.time)}</span>
                        </div>
                        {appointment.amount && (
                          <div className="flex items-center text-sm text-gray-600">
                            <div className="flex items-center justify-center w-4 h-4 mr-2">
                              <i className="ri-money-dollar-circle-line"></i>
                            </div>
                            <span>${appointment.amount.toLocaleString()} COP</span>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEdit(appointment)}
                          className="flex-1 bg-blue-50 text-blue-700 py-2 rounded-lg text-sm font-medium !rounded-button"
                        >
                          <div className="flex items-center justify-center">
                            <div className="flex items-center justify-center w-4 h-4 mr-1">
                              <i className="ri-edit-line"></i>
                            </div>
                            Editar
                          </div>
                        </button>
                        <button
                          onClick={() => setShowDeleteConfirm(appointment.id)}
                          className="flex-1 bg-red-50 text-red-700 py-2 rounded-lg text-sm font-medium !rounded-button"
                        >
                          <div className="flex items-center justify-center">
                            <div className="flex items-center justify-center w-4 h-4 mr-1">
                              <i className="ri-delete-bin-line"></i>
                            </div>
                            Cancelar
                          </div>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <div className="text-center mb-6">
              <div className="flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mx-auto mb-4">
                <i className="ri-delete-bin-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-800 mb-2">¿Cancelar Cita?</h3>
              <p className="text-gray-600 text-sm">Esta acción no se puede deshacer</p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium !rounded-button"
              >
                No, mantener
              </button>
              <button
                onClick={() => handleDelete(showDeleteConfirm)}
                className="flex-1 bg-red-600 text-white py-3 rounded-xl font-medium !rounded-button"
              >
                Sí, cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
